package com.example.task21p;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText inputNumber;

    TextView centimetreResult;
    TextView footResult;
    TextView inchResult;

    TextView gramResult;
    TextView ounceResult;
    TextView poundResult;

    TextView fahrenheitResult;
    TextView kelvinResult;

    TextView centimetreText;
    TextView footText;
    TextView inchText;

    TextView gramText;
    TextView ounceText;
    TextView poundText;

    TextView fahrenheitText;
    TextView kelvinText;

    TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumber = findViewById(R.id.editTextNumber);

        centimetreResult = findViewById(R.id.centimetreResult);
        footResult = findViewById(R.id.footResult);
        inchResult = findViewById(R.id.inchResult);

        gramResult = findViewById(R.id.gramResult);
        ounceResult = findViewById(R.id.ounceResult);
        poundResult = findViewById(R.id.poundResult);

        fahrenheitResult = findViewById(R.id.fahrenheitResult);
        kelvinResult = findViewById(R.id.kelvinResult);

        centimetreText = findViewById(R.id.centimetreText);
        footText = findViewById(R.id.footText);
        inchText = findViewById(R.id.inchText);

        gramText = findViewById(R.id.gramText);
        ounceText = findViewById(R.id.ounceText);
        poundText = findViewById(R.id.poundText);

        fahrenheitText = findViewById(R.id.fahrenheitText);
        kelvinText = findViewById(R.id.kelvinText);

        errorText = findViewById(R.id.errorText);

        ImageButton buttonLength = findViewById(R.id.imageButtonLength);
        ImageButton buttonTemperature = findViewById(R.id.imageButtonTemp);
        ImageButton buttonWeight = findViewById(R.id.imageButtonWeight);

        // gets the spinner item from the XML design
        Spinner dropdownMenu = findViewById(R.id.spinnerMenu);
        // creates a list called options with the 3 different conversions/menu items needed
        String[] options = new String[]{"Metre", "Celsius", "Kilograms"};
        // adapter created to display the options
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, options);
        // sets the spinner adapter to the new one
        dropdownMenu.setAdapter(adapter);

        buttonLength.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = dropdownMenu.getSelectedItem().toString();

                if (text == "Metre")
                {
                    errorText.setVisibility(View.INVISIBLE);

                    Float input = Float.parseFloat(inputNumber.getText().toString());

                    Float result1 = input * 100f;
                    centimetreResult.setText(String.format("%.2f", result1));

                    Float result2 = input * 3.281f;
                    footResult.setText(String.format("%.2f", result2));

                    Float result3 = input * 39.37f;
                    inchResult.setText(String.format("%.2f", result3));

                    centimetreResult.setVisibility(View.VISIBLE);
                    footResult.setVisibility(View.VISIBLE);
                    inchResult.setVisibility(View.VISIBLE);

                    gramResult.setVisibility(View.INVISIBLE);
                    ounceResult.setVisibility(View.INVISIBLE);
                    poundResult.setVisibility(View.INVISIBLE);

                    fahrenheitResult.setVisibility(View.INVISIBLE);
                    kelvinResult.setVisibility(View.INVISIBLE);

                    centimetreText.setVisibility(View.VISIBLE);
                    footText.setVisibility(View.VISIBLE);
                    inchText.setVisibility(View.VISIBLE);

                    gramText.setVisibility(View.INVISIBLE);
                    ounceText.setVisibility(View.INVISIBLE);
                    poundText.setVisibility(View.INVISIBLE);

                    fahrenheitText.setVisibility(View.INVISIBLE);
                    kelvinText.setVisibility(View.INVISIBLE);
                }
                else
                {
                    errorText.setVisibility(View.VISIBLE);
                }
            }
        });

        buttonTemperature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = dropdownMenu.getSelectedItem().toString();

                if (text == "Celsius")
                {
                    errorText.setVisibility(View.INVISIBLE);

                    Float input = Float.parseFloat(inputNumber.getText().toString());

                    Float result1 = (input * 9f/5f) + 32f;
                    fahrenheitResult.setText(String.format("%.2f", result1));

                    Float result2 = input + 273.15f;
                    kelvinResult.setText(String.format("%.2f", result2));

                    centimetreResult.setVisibility(View.INVISIBLE);
                    footResult.setVisibility(View.INVISIBLE);
                    inchResult.setVisibility(View.INVISIBLE);

                    gramResult.setVisibility(View.INVISIBLE);
                    ounceResult.setVisibility(View.INVISIBLE);
                    poundResult.setVisibility(View.INVISIBLE);

                    fahrenheitResult.setVisibility(View.VISIBLE);
                    kelvinResult.setVisibility(View.VISIBLE);

                    centimetreText.setVisibility(View.INVISIBLE);
                    footText.setVisibility(View.INVISIBLE);
                    inchText.setVisibility(View.INVISIBLE);

                    gramText.setVisibility(View.INVISIBLE);
                    ounceText.setVisibility(View.INVISIBLE);
                    poundText.setVisibility(View.INVISIBLE);

                    fahrenheitText.setVisibility(View.VISIBLE);
                    kelvinText.setVisibility(View.VISIBLE);
                }
                else
                {
                    errorText.setVisibility(View.VISIBLE);
                }
            }
        });

        buttonWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = dropdownMenu.getSelectedItem().toString();

                if (text == "Kilograms")
                {
                    errorText.setVisibility(View.INVISIBLE);

                    Float input = Float.parseFloat(inputNumber.getText().toString());

                    Float result1 = input * 1000f;
                    gramResult.setText(String.format("%.2f", result1));

                    Float result2 = input * 35.274f;
                    ounceResult.setText(String.format("%.2f", result2));

                    Float result3 = input * 2.205f;
                    poundResult.setText(String.format("%.2f", result3));

                    centimetreResult.setVisibility(View.INVISIBLE);
                    footResult.setVisibility(View.INVISIBLE);
                    inchResult.setVisibility(View.INVISIBLE);

                    gramResult.setVisibility(View.VISIBLE);
                    ounceResult.setVisibility(View.VISIBLE);
                    poundResult.setVisibility(View.VISIBLE);

                    fahrenheitResult.setVisibility(View.INVISIBLE);
                    kelvinResult.setVisibility(View.INVISIBLE);

                    centimetreText.setVisibility(View.INVISIBLE);
                    footText.setVisibility(View.INVISIBLE);
                    inchText.setVisibility(View.INVISIBLE);

                    gramText.setVisibility(View.VISIBLE);
                    ounceText.setVisibility(View.VISIBLE);
                    poundText.setVisibility(View.VISIBLE);

                    fahrenheitText.setVisibility(View.INVISIBLE);
                    kelvinText.setVisibility(View.INVISIBLE);
                }
                else
                {
                    errorText.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}